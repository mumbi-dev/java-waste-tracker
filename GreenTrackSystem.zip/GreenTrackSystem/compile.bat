@echo off
echo Compiling GreenTrack...

if not exist out mkdir out

javac -d out ^
  src\model\WasteItem.java ^
  src\model\PlasticWaste.java ^
  src\model\OrganicWaste.java ^
  src\model\HazardousWaste.java ^
  src\model\Household.java ^
  src\model\Collector.java ^
  src\myInterface\WasteTrackable.java ^
  src\exceptionpkg\InvalidWasteTypeException.java ^
  src\exceptionpkg\InvalidWasteWeightException.java ^
  src\service\ValidationService.java ^
  src\service\RegistrationService.java ^
  src\service\WasteService.java ^
  src\util\GreenTrackUtils.java ^
  src\util\SystemReport.java ^
  src\main\Main.java

if %ERRORLEVEL% == 0 (
    echo.
    echo Compilation successful!
    echo Run "run.bat" to start GreenTrack.
) else (
    echo.
    echo Compilation failed. Check the errors above.
)
pause
