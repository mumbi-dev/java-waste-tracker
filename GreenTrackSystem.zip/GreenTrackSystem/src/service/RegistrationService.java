package service;

import model.Collector;
import model.Household;

import java.util.ArrayList;
import java.util.List;

public class RegistrationService {

    private List<Household> households;
    private List<Collector> collectors;

    public RegistrationService() {
        households = new ArrayList<>();
        collectors = new ArrayList<>();
    }

    public void registerHousehold(Household h) {
        households.add(h);
        System.out.println("Household registered successfully.");
    }

    public void registerCollector(Collector c) {
        collectors.add(c);
        System.out.println("Collector registered successfully.");
    }

    public Household findHouseholdByID(String id) {
        for (Household h : households) {
            if (h.getHouseholdID().equals(id)) {
                return h;
            }
        }
        return null;
    }

    public List<Household> getHouseholds() {
        return households;
    }

    public List<Collector> getCollectors() {
        return collectors;
    }

    public int getTotalHouseholds() {
        return households.size();
    }

    public int getTotalCollectors() {
        return collectors.size();
    }
}
