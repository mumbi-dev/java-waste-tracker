package service;

public class ValidationService {

    // checks if a string is null or empty
    public boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    // validates that a weight is a positive number
    public boolean isValidWeight(double weight) {
        return weight > 0;
    }

    // validates that the waste type is one of the accepted types
    public boolean isValidWasteType(String wasteType) {
        if (wasteType == null) {
            return false;
        }
        String type = wasteType.toLowerCase().trim();
        return type.equals("plastic") || type.equals("organic") || type.equals("hazardous");
    }
}
