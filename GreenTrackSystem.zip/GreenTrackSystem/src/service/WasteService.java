package service;

import exceptionpkg.InvalidWasteTypeException;
import exceptionpkg.InvalidWasteWeightException;
import model.*;

public class WasteService {

    public WasteItem createWasteItem(String itemName, String wasteType, double weight)
            throws InvalidWasteTypeException, InvalidWasteWeightException {

        if (weight <= 0) {
            throw new InvalidWasteWeightException("Weight cannot be zero or negative. Please enter a valid weight.");
        }

        switch (wasteType.toLowerCase()) {
            case "plastic":
                return new PlasticWaste(itemName, weight);
            case "organic":
                return new OrganicWaste(itemName, weight);
            case "hazardous":
                return new HazardousWaste(itemName, weight);
            default:
                throw new InvalidWasteTypeException("Unsupported waste type: " + wasteType +
                        ". Valid types are: Plastic, Organic, Hazardous.");
        }
    }

    public void displayAllSubmissions(RegistrationService regService) {
        if (regService.getHouseholds().isEmpty()) {
            System.out.println("No households registered yet.");
            return;
        }

        for (Household h : regService.getHouseholds()) {
            System.out.println("\nHousehold ID: " + h.getHouseholdID() + ", Name: " + h.getHeadOfHousehold());
            if (h.getWasteSubmissions().isEmpty()) {
                System.out.println("  No waste submissions yet.");
            } else {
                System.out.println("  Waste Submissions:");
                for (WasteItem item : h.getWasteSubmissions()) {
                    System.out.println("    - " + item.toString());
                }
            }
        }
    }

    public void displayEcoScores(RegistrationService regService) {
        if (regService.getHouseholds().isEmpty()) {
            System.out.println("No households registered yet.");
            return;
        }

        for (Household h : regService.getHouseholds()) {
            System.out.println("Household: " + h.getHeadOfHousehold() + " (ID: " + h.getHouseholdID() + ")");
            System.out.println("  Total Eco-Score: " + String.format("%.2f", h.getTotalEcoScore()) + " GSP");
        }
    }
}
