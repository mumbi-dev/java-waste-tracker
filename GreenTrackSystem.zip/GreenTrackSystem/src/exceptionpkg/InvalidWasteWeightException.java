package exceptionpkg;

public class InvalidWasteWeightException extends Exception {

    public InvalidWasteWeightException(String message) {
        super(message);
    }
}
