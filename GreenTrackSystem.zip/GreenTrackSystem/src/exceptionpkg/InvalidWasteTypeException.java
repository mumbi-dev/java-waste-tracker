package exceptionpkg;

public class InvalidWasteTypeException extends Exception {

    public InvalidWasteTypeException(String message) {
        super(message);
    }
}
