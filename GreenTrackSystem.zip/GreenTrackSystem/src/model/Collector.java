package model;

public class Collector {

    private String collectorID;
    private String name;
    private String serviceArea;

    public Collector(String collectorID, String name, String serviceArea) {
        this.collectorID = collectorID;
        this.name = name;
        this.serviceArea = serviceArea;
    }

    public String getCollectorID() {
        return collectorID;
    }

    public void setCollectorID(String collectorID) {
        this.collectorID = collectorID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getServiceArea() {
        return serviceArea;
    }

    public void setServiceArea(String serviceArea) {
        this.serviceArea = serviceArea;
    }

    @Override
    public String toString() {
        return "Collector ID: " + collectorID + ", Name: " + name + ", Service Area: " + serviceArea;
    }
}
