package model;

public class OrganicWaste extends WasteItem {

    public OrganicWaste(String itemName, double weight) {
        super(itemName, "Organic", weight);
    }

    @Override
    public double getGSPMultiplier() {
        return 0.5;
    }
}
