package model;

public class HazardousWaste extends WasteItem {

    public HazardousWaste(String itemName, double weight) {
        super(itemName, "Hazardous", weight);
    }

    @Override
    public double getGSPMultiplier() {
        return 6.0;
    }
}
