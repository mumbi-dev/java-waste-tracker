package model;

import java.util.ArrayList;
import java.util.List;

public class Household {

    private String householdID;
    private String headOfHousehold;
    private String contactNumber;
    private String address;
    private List<WasteItem> wasteSubmissions;

    public Household(String householdID, String headOfHousehold, String contactNumber, String address) {
        this.householdID = householdID;
        this.headOfHousehold = headOfHousehold;
        this.contactNumber = contactNumber;
        this.address = address;
        this.wasteSubmissions = new ArrayList<>();
    }

    public String getHouseholdID() {
        return householdID;
    }

    public void setHouseholdID(String householdID) {
        this.householdID = householdID;
    }

    public String getHeadOfHousehold() {
        return headOfHousehold;
    }

    public void setHeadOfHousehold(String headOfHousehold) {
        this.headOfHousehold = headOfHousehold;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<WasteItem> getWasteSubmissions() {
        return wasteSubmissions;
    }

    public void addWasteItem(WasteItem item) {
        wasteSubmissions.add(item);
    }

    public double getTotalEcoScore() {
        double total = 0;
        for (WasteItem item : wasteSubmissions) {
            total += item.calculateImpactScore();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Household ID: " + householdID + ", Name: " + headOfHousehold;
    }
}
