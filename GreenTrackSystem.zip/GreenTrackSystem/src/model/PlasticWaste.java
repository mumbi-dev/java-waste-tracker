package model;

public class PlasticWaste extends WasteItem {

    public PlasticWaste(String itemName, double weight) {
        super(itemName, "Plastic", weight);
    }

    @Override
    public double getGSPMultiplier() {
        return 3.0;
    }
}
