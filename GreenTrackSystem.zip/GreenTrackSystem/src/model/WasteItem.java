package model;

import myInterface.WasteTrackable;

public abstract class WasteItem implements WasteTrackable {

    private String itemName;
    private String wasteType;
    private double weight;

    public WasteItem(String itemName, String wasteType, double weight) {
        this.itemName = itemName;
        this.wasteType = wasteType;
        this.weight = weight;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getWasteType() {
        return wasteType;
    }

    public void setWasteType(String wasteType) {
        this.wasteType = wasteType;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    // Each subclass will implement its own multiplier
    public abstract double getGSPMultiplier();

    @Override
    public double calculateImpactScore() {
        return weight * getGSPMultiplier();
    }

    @Override
    public String toString() {
        return wasteType + ": " + itemName + " (" + String.format("%.2f", weight) + " kg)" +
                " ? Impact: " + String.format("%.2f", calculateImpactScore()) + " GSP";
    }
}
