package myInterface;

public interface WasteTrackable {

    double calculateImpactScore();

    double getGSPMultiplier();
}
