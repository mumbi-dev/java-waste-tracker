package main;

import exceptionpkg.InvalidWasteTypeException;
import exceptionpkg.InvalidWasteWeightException;
import model.Collector;
import model.Household;
import model.WasteItem;
import service.RegistrationService;
import service.ValidationService;
import service.WasteService;
import util.GreenTrackUtils;
import util.SystemReport;

import java.util.Scanner;

public class Main {

    static RegistrationService regService = new RegistrationService();
    static WasteService wasteService = new WasteService();
    static ValidationService validationService = new ValidationService();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        int choice = 0;

        do {
            System.out.println("\n===== GreenTrack System =====");
            System.out.println("1. Register Household");
            System.out.println("2. Register Collector");
            System.out.println("3. Submit Waste");
            System.out.println("4. View All Submissions");
            System.out.println("5. Calculate Eco-Score");
            System.out.println("6. View System Report");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 7.");
                continue;
            }

            switch (choice) {
                case 1:
                    registerHousehold();
                    break;
                case 2:
                    registerCollector();
                    break;
                case 3:
                    submitWaste();
                    break;
                case 4:
                    wasteService.displayAllSubmissions(regService);
                    break;
                case 5:
                    wasteService.displayEcoScores(regService);
                    break;
                case 6:
                    SystemReport.generateReport(regService);
                    break;
                case 7:
                    System.out.println("Exiting GreenTrack. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please choose between 1 and 7.");
            }

        } while (choice != 7);

        scanner.close();
    }

    private static void registerHousehold() {
        System.out.println("--- Register New Household ---");

        String id = "";
        while (validationService.isNullOrEmpty(id)) {
            System.out.print("Enter Household ID: ");
            id = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(id)) {
                System.out.println("Household ID cannot be empty.");
            }
        }

        String name = "";
        while (validationService.isNullOrEmpty(name)) {
            System.out.print("Enter Head of Household Name: ");
            name = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(name)) {
                System.out.println("Name cannot be empty.");
            }
        }

        String contact = "";
        while (validationService.isNullOrEmpty(contact)) {
            System.out.print("Enter Contact Number: ");
            contact = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(contact)) {
                System.out.println("Contact number cannot be empty.");
            }
        }

        String address = "";
        while (validationService.isNullOrEmpty(address)) {
            System.out.print("Enter Address: ");
            address = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(address)) {
                System.out.println("Address cannot be empty.");
            }
        }

        Household household = new Household(id, name, contact, address);
        regService.registerHousehold(household);
    }

    private static void registerCollector() {
        System.out.println("--- Register New Collector ---");

        String id = "";
        while (validationService.isNullOrEmpty(id)) {
            System.out.print("Enter Collector ID: ");
            id = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(id)) {
                System.out.println("Collector ID cannot be empty.");
            }
        }

        String name = "";
        while (validationService.isNullOrEmpty(name)) {
            System.out.print("Enter Collector Name: ");
            name = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(name)) {
                System.out.println("Name cannot be empty.");
            }
        }

        String area = "";
        while (validationService.isNullOrEmpty(area)) {
            System.out.print("Enter Service Area: ");
            area = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(area)) {
                System.out.println("Service area cannot be empty.");
            }
        }

        Collector collector = new Collector(id, name, area);
        regService.registerCollector(collector);
    }

    private static void submitWaste() {
        if (regService.getHouseholds().isEmpty()) {
            System.out.println("No households registered. Please register a household first.");
            return;
        }

        System.out.print("Enter Household ID: ");
        String id = scanner.nextLine().trim();

        Household household = regService.findHouseholdByID(id);
        if (household == null) {
            System.out.println("Household not found with ID: " + id);
            return;
        }

        String itemName = "";
        while (validationService.isNullOrEmpty(itemName)) {
            System.out.print("Enter Waste Item Name: ");
            itemName = scanner.nextLine().trim();
            if (validationService.isNullOrEmpty(itemName)) {
                System.out.println("Item name cannot be empty.");
            }
        }

        String wasteType = "";
        while (!validationService.isValidWasteType(wasteType)) {
            System.out.print("Enter Waste Type (Plastic/Organic/Hazardous): ");
            wasteType = scanner.nextLine().trim();
            if (!validationService.isValidWasteType(wasteType)) {
                System.out.println("Invalid waste type. Please enter Plastic, Organic, or Hazardous.");
            }
        }

        double weight = -1;
        while (weight <= 0) {
            System.out.print("Enter Weight in kg: ");
            try {
                weight = Double.parseDouble(scanner.nextLine().trim());
                if (weight <= 0) {
                    System.out.println("Weight must be greater than zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number for weight.");
            }
        }

        try {
            WasteItem item = wasteService.createWasteItem(itemName, wasteType, weight);
            household.addWasteItem(item);
            System.out.println("Impact Score for this item: " + String.format("%.2f", item.calculateImpactScore()) + " GSP");

            // also show the weight conversion if large enough
            if (weight >= 1000) {
                System.out.println("Note: That's " + GreenTrackUtils.formatWeight(weight));
            }
        } catch (InvalidWasteTypeException | InvalidWasteWeightException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
