package util;

import model.Household;
import model.WasteItem;
import service.RegistrationService;

public class SystemReport {

    public static void generateReport(RegistrationService regService) {
        System.out.println("\n=== SYSTEM REPORT ===");
        System.out.println("Total Registered Households: " + regService.getTotalHouseholds());
        System.out.println("Total Registered Collectors: " + regService.getTotalCollectors());

        // track totals per category
        double totalPlasticWeight = 0;
        double totalOrganicWeight = 0;
        double totalHazardousWeight = 0;

        double plasticGSP = 0;
        double organicGSP = 0;
        double hazardousGSP = 0;

        for (Household h : regService.getHouseholds()) {
            for (WasteItem item : h.getWasteSubmissions()) {
                String type = item.getWasteType().toLowerCase();
                if (type.equals("plastic")) {
                    totalPlasticWeight += item.getWeight();
                    plasticGSP += item.calculateImpactScore();
                } else if (type.equals("organic")) {
                    totalOrganicWeight += item.getWeight();
                    organicGSP += item.calculateImpactScore();
                } else if (type.equals("hazardous")) {
                    totalHazardousWeight += item.getWeight();
                    hazardousGSP += item.calculateImpactScore();
                }
            }
        }

        System.out.println("Total Waste Submitted by Category:");
        if (totalPlasticWeight > 0) {
            System.out.println("  - Plastic: " + GreenTrackUtils.formatWeight(totalPlasticWeight));
        }
        if (totalOrganicWeight > 0) {
            System.out.println("  - Organic: " + GreenTrackUtils.formatWeight(totalOrganicWeight));
        }
        if (totalHazardousWeight > 0) {
            System.out.println("  - Hazardous: " + GreenTrackUtils.formatWeight(totalHazardousWeight));
        }
        if (totalPlasticWeight == 0 && totalOrganicWeight == 0 && totalHazardousWeight == 0) {
            System.out.println("  No waste submitted yet.");
        }

        System.out.println("Total Eco-Impact Score by Category:");
        if (plasticGSP > 0) {
            System.out.println("  - Plastic: " + String.format("%.2f", plasticGSP) + " GSP");
        }
        if (organicGSP > 0) {
            System.out.println("  - Organic: " + String.format("%.2f", organicGSP) + " GSP");
        }
        if (hazardousGSP > 0) {
            System.out.println("  - Hazardous: " + String.format("%.2f", hazardousGSP) + " GSP");
        }
        if (plasticGSP == 0 && organicGSP == 0 && hazardousGSP == 0) {
            System.out.println("  No impact scores calculated yet.");
        }
    }
}
