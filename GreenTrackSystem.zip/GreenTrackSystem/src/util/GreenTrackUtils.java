package util;

public class GreenTrackUtils {

    // converts kilograms to tons
    public static double kgToTons(double kg) {
        return kg / 1000.0;
    }

    // converts tons to kilograms
    public static double tonsToKg(double tons) {
        return tons * 1000.0;
    }

    // formats the weight display - shows tons if >= 1000 kg
    public static String formatWeight(double kg) {
        if (kg >= 1000) {
            return String.format("%.2f", kgToTons(kg)) + " tons";
        } else {
            return String.format("%.2f", kg) + " kg";
        }
    }

    // just a small helper to print a line separator
    public static void printSeparator() {
        System.out.println("------------------------------------");
    }
}
